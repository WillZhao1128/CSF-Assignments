Names: Aidan Aug, Will Zhao

HW Contributions for Milestone1:
Aidan Aug: Implemented functions in c_textsearch_fns.c and c_textsearch.c

Will Zhao: debugging, testing and final submission

