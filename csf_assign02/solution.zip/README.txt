Names: Aidan Aug, Will Zhao

HW Contributions for Milestone1:
Aidan Aug: Implemented functions in c_textsearch_fns.c and c_textsearch.c

Will Zhao: debugging, testing and final submission

HW Contributions for Milestone 2:
Aidan Aug: Implemented find_string_length (and read_line) in Assembly

Will Zhao: debugging, writing more tests, final submission.


HW Contributions for Milestone 3:
Aidan Aug: Implemented print_line, count_occurrences, and calc_total_occurrences.

Will Zhao: implemented strings_equal, handle_arguments.

Both: Worked on main, debugged, touched up testing and style.
