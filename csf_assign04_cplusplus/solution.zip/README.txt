TODO: describe the contributions of each team member

Aidan Aug:

Will Zhao:
