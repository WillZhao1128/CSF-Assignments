TODO: describe the contributions of each team member

Aidan Aug: Implemented argument handling, as well as printing all the associated data related to
           the section headers. Started on printing the output for symbols.

Will Zhao: Implemented printing the output to all the data associated related to the symbols.
           Doubled checked style and coding guidelines.
