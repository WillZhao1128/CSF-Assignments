Names: Aidan Aug, Will Zhao

HW Contributions for Milestone 1:

Aidan Aug: Created helper.h, helper.cpp, main.cpp. Also implemented main and handle arguments.

Will Zhao: Debugging, makefile. Implemented is_valid_number. Also checked style.


HW Contributions for Milestone 2:

Aidan Aug: Added and coded cache.h, cache.cpp, set.h, set.cpp, block.h

Will Zhao: Worked on main, helper.h, helper.cpp. Debugged cycles, checked valgrind.
