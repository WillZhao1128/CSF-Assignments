Names: Aidan Aug, Will Zhao

HW Contributions for Milestone1:

Aidan Aug: Created helper.h, helper.cpp, main.cpp. Also implemented main and handle arguments.

Will Zhao: Debugging, makefile. Implemented is_valid_number. Also checked style.

