HW 5 Contributions:

Aidan Aug: Implemented calculator and all associated functions. Helped debug calcServer

Will Zhao: Implemented calcServer and all associated functions.