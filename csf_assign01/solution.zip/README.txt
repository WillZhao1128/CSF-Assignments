Names: Aidan Aug, Will Zhao

HW Contributions:
Aidan Aug: Prepared outline/pseudocode of all required functions for Milestone1, including create, create2, whole_part, frac_part, and is_zero. Prepared submission and README.txt.

Will Zhao: Wrote the code in C++. Tested functions.

**Note that both Aidan Aug and Will Zhao worked together (in person and on the same computer) to code the required functions. Also utilized GitHub to work together.

